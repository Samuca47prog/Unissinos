
public class EscolaDeSamba {
	private String nome;
	private char grupo;
	private String dataDeCriacao;
	private String sambaEnredo;
	public String carnavalesco;
	private int quantAlas;
	
	public void desfilar() {
		
	}
	
	public int calcularNota(int nota) {
		
	}
	
	public void criarIngresso(String vip) {
		
	}
	
	public void cadastrarPassista() {
		
	}
}
