
public class Imovel {
	private String tipo;
	private String local;
	private int ano;
	public String imobiliaria;
	private boolean valor;
	
	public int calcularIPTU(int valor) {
		
	}
	
	public void visualizarInfo() {
		
	}
	
	public boolean alugado() {
		
	}
	
	public boolean imobiliado() {
		
	}
	
	public String pontosReferencia() {
		
	}
	
	public String acesso(String rua) {
		
	}
	
	public boolean escritura() {
		
	}
}
