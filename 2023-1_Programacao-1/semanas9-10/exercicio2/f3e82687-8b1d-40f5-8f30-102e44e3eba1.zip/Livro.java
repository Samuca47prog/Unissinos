
public class Livro {
	private String titulo;
	private String autor;
	private int ano;
	private String editora;
	private boolean disponivel;
	
	public void cadastrarAutor(String nome) {
		
	}
	
	public String verificarISBN() {
		
	}
	
	public boolean disponibilidade() {
		
	}
}
