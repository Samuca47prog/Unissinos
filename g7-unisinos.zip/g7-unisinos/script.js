document.getElementById('formulario-imc').addEventListener('submit', function(evento) {
    evento.preventDefault();

    var peso = parseFloat(document.getElementById('peso').value);
    var altura = parseFloat(document.getElementById('altura').value);

    if (peso > 0 && altura > 0) {
        var imc = (peso / Math.pow(altura / 100, 2)).toFixed(1);
        var resultado = "Seu IMC é: " + imc;

        // Classificar o IMC em categorias
        if (imc < 18.5) {
            resultado += ' - Classificação: Abaixo do peso';
        } else if (imc < 24.9) {
            resultado += ' - Classificação: Peso normal';
        } else if (imc < 29.9) {
            resultado += '  - Classificação: Sobrepeso';
        } else if (imc < 34.9) {
            resultado += ' - Classificação: Obesidade grau I';
        } else if (imc < 39.9) {
            resultado += ' - Classificação: Obesidade grau II';
        } else {
            resultado += ' - Classificação: Obesidade grau III';
        }
        
        document.getElementById('resultado-imc').innerText = resultado;
    } else {
        document.getElementById('resultado-imc').innerText = "Por favor, insira valores válidos para peso e altura.";
    }

});
